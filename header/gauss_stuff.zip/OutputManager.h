#pragma once
// header/OutputManager.h
// Output directory management and sequential file numbering.
//
// Expected structure (created once by the user):
//   macro/
//   ├── 04_multi_scan/          <- program runs here
//   ├── canvas/                 <- created by user
//   └── file_root/              <- created by user
//
// The program creates automatically:
//   macro/canvas/YYYYMMDD_HHMMSS/    ← tutti i PNG numerati
//   macro/file_root/YYYYMMDD_HHMMSS/ ← tutti i ROOT numerati
//
// Uso:
//   OutCtx ctx = createOutputDirs();
//   canvas->SaveAs(ctx.png("tot_map_vbias55.png").c_str());
//   // → macro/canvas/20260401_143022/01_tot_map_vbias55.png
//   ctx.saveRoot(h2D, h2D_corr, "tag", 1.0);
//   // → macro/file_root/20260401_143022/14_tot_tag_let1.00pe.root

#include <string>
#include <ctime>
#include <TFile.h>
#include <TH2D.h>
#include <TCanvas.h>
#include <TSystem.h>

// ════════════════════════════════════════════════════════════
//  OutCtx — output context
//  Holds the two output directories and the global sequential counter.
//  A single instance is created in main and passed by reference
//  to all functions that save files.
// ════════════════════════════════════════════════════════════
struct OutCtx {
    std::string pngDir;   // macro/canvas/YYYYMMDD_HHMMSS
    std::string rootDir;  // macro/file_root/YYYYMMDD_HHMMSS
    int         n = 0;    // contatore globale progressivo

    // ── PNG ────────────────────────────────────────────────
    // Returns the full path for the next PNG file.
    // Increments the global counter.
    std::string png(const std::string& name) {
        return Form("%s/%02d_%s", pngDir.c_str(), ++n, name.c_str());
    }

    // Saves a canvas as a PNG with the next sequential number.
    // Sets kCanDelete=false before saving to prevent ROOT from
    // auto-deleting the canvas while SaveAs is still writing the file.
    void savePNG(TCanvas* c, const std::string& name) {
        if (c) c->SetBit(TObject::kCanDelete, false);
        c->SaveAs(png(name).c_str());
    }

    // ── ROOT ───────────────────────────────────────────────
    // Returns the full path for the next ROOT file.
    std::string root(const std::string& name) {
        return Form("%s/%02d_%s", rootDir.c_str(), ++n, name.c_str());
    }

    // Saves TOT maps (raw and corrected) to a numbered ROOT file.
    void saveRoot(TH2D* h2D, TH2D* h2D_corr,
                  const std::string& tag, double frac_pe) {
        std::string fname = root(Form("tot_%s_let%.2fpe.root",
                                      tag.c_str(), frac_pe));
        TFile* fout = new TFile(fname.c_str(), "RECREATE");
        if (h2D)      h2D->Write("h2D");
        if (h2D_corr) h2D_corr->Write("h2D_corrected");
        fout->Write(); fout->Close();
        std::cout << "  Root file: " << fname << "\n";
    }
};

// ════════════════════════════════════════════════════════════
//  createOutputDirs()
//  Creates timestamped subdirectories inside canvas/ and file_root/
//  and returns a ready-to-use OutCtx.
//  Must be called once at the start of main.
// ════════════════════════════════════════════════════════════
static OutCtx createOutputDirs() {
    // Timestamp YYYYMMDD_HHMMSS
    time_t now = time(nullptr);
    struct tm* t = localtime(&now);
    char ts[32];
    strftime(ts, sizeof(ts), "%Y%m%d_%H%M%S", t);

    // The program runs in macro/04_multi_scan/ (or similar).
    // The canvas/ and file_root/ directories are in macro/ -> ../
    std::string pngBase  = "../canvas";
    std::string rootBase = "../file_root";
    std::string pngDir   = pngBase  + "/" + std::string(ts);
    std::string rootDir  = rootBase + "/" + std::string(ts);

    // Create subdirectories (base dirs must already exist, created by user)
    if (gSystem->mkdir(pngDir.c_str(),  true) != 0)
        std::cerr << "[OUT] Cannot create " << pngDir  << "\n";
    if (gSystem->mkdir(rootDir.c_str(), true) != 0)
        std::cerr << "[OUT] Cannot create " << rootDir << "\n";

    OutCtx ctx;
    ctx.pngDir  = pngDir;
    ctx.rootDir = rootDir;
    ctx.n       = 0;

    std::cout << "  PNG  folder : " << pngDir  << "\n"
              << "  ROOT folder : " << rootDir << "\n";
    return ctx;
}
