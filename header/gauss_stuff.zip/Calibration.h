#pragma once
// header/Calibration.h
// p.e. calibration via threshold scan -- TOT-compatible method.
//
// Fisicamente: si varia la soglia del discriminatore e si conta quanti
// events exceed it (with 50% hysteresis). The N(V) curve is the distribution
// cumulativa delle ampiezze. La derivata -dN/dV mostra picchi discreti
// at multiples of p.e. -- exactly as sipm_pespectrum_scan.cpp does.
// This method uses ONLY "did it exceed the threshold?" -> consistent with TOT.
//
// Funzioni esportate:
//   calibrateSpectrum()   -- calibrates a single file, saves per-file canvas
//   drawCalibOverlay()    — overlay di tutti i file (come all_scans/all_derivs)
//   printFileList()       — stampa lista file trovati
//   selectOneFile()       — selezione interattiva singolo file
//   selectMultipleFiles() — selezione interattiva multipla

#include "Config.h"
#include "SignalProcessing.h"
#include "OutputManager.h"
#include <vector>
#include <string>
#include <algorithm>
#include <numeric>
#include <iomanip>
#include <iostream>
#include <sstream>
#include <TFile.h>
#include <TTree.h>
#include <TH1D.h>
#include <TGraphErrors.h>
#include <TF1.h>
#include <TLine.h>
#include <TCanvas.h>
#include <TPad.h>
#include <TPaveText.h>
#include <TLegend.h>
#include <TROOT.h>
#include <TSystem.h>

// ════════════════════════════════════════════════════════════
//  SELEZIONE INTERATTIVA DEI FILE
// ════════════════════════════════════════════════════════════
static void printFileList(const std::vector<FileInfo>& files) {
    std::cout << "\nFiles found:\n";
    for (int i = 0; i < (int)files.size(); ++i)
        std::cout << "  [" << i << "] " << files[i].tag << "\n";
}

static int selectOneFile(const std::vector<FileInfo>& files,
                         const std::string& prompt) {
    int idx = -1;
    while (idx < 0 || idx >= (int)files.size()) {
        std::cout << prompt;
        std::cin >> idx;
        if (idx < 0 || idx >= (int)files.size())
            std::cout << "  [ERROR] Invalid index. Enter 0-"
                      << files.size()-1 << ".\n";
    }
    return idx;
}

static std::vector<int> selectMultipleFiles(const std::vector<FileInfo>& files,
                                             const std::string& prompt) {
    std::vector<int> selected;
    std::string line;
    std::cin.ignore();
    while (selected.empty()) {
        std::cout << prompt;
        std::getline(std::cin, line);
        if (line == "all" || line == "ALL") {
            for (int i = 0; i < (int)files.size(); ++i)
                selected.push_back(i);
            break;
        }
        std::stringstream ss(line);
        std::string tok;
        bool ok = true;
        while (std::getline(ss, tok, ',')) {
            try {
                int i = std::stoi(tok);
                if (i < 0 || i >= (int)files.size()) { ok = false; break; }
                selected.push_back(i);
            } catch (...) { ok = false; break; }
        }
        if (!ok || selected.empty()) {
            selected.clear();
            std::cout << "  [ERROR] Enter indices like \"2\" or \"0,2\" or \"all\".\n";
        }
    }
    return selected;
}

// ════════════════════════════════════════════════════════════
//  RISULTATO CALIBRAZIONE
// ════════════════════════════════════════════════════════════
struct CalibResult {
    double m          = 0;     // guadagno [mV/p.e.]
    double q          = 0;     // offset   [mV]
    bool   ok         = false; // calibrazione riuscita
    double laser_thr  = 10.0;  // soglia canale laser [mV] — calibrata automaticamente
    double t_trig_start = 95.0;  // inizio finestra trigger [ns]
    double t_trig_end   = 125.0; // fine finestra trigger [ns]
    double cutoff_MHz   = 200.0; // cutoff filtro LP [MHz]
};

// ════════════════════════════════════════════════════════════
//  DATI GREZZI DEL SCAN  (per l'overlay multi-file)
//  Viene riempito da calibrateSpectrum se si passa un puntatore.
//  Permette a drawCalibOverlay() di ricostruire i grafici
//  senza rileggere i file ROOT di input.
// ════════════════════════════════════════════════════════════
struct CalibScanData {
    std::string          tag;         // etichetta file (es. "vbias55_filter3")
    std::vector<double>  thresholds;  // soglie della scansione [mV]
    std::vector<double>  counts;      // N(V): quanti eventi superano ogni soglia
    std::vector<double>  thr_der;     // ascissa della derivata [mV]
    std::vector<double>  deriv;       // -dN/dV [mV⁻¹]
    std::vector<double>  pkPos;       // posizione dei picchi accettati [mV]
    double               gain  = 0;
    double               offset= 0;
};

// ════════════════════════════════════════════════════════════
//  PALETTE COLORI  (identica a read_all_scans.cpp)
// ════════════════════════════════════════════════════════════
static int calibColor(int idx) {
    static const int pal[] = {
        kAzure+1, kOrange+7, kGreen+2, kMagenta+1,
        kRed+1,   kCyan+2,   kViolet+1, kYellow+3
    };
    return pal[idx % (int)(sizeof(pal)/sizeof(pal[0]))];
}

// ════════════════════════════════════════════════════════════
//  CALIBRATION VIA THRESHOLD SCAN  (TOT-compatible method)
//
//  scanOut — se non nullptr, viene riempito con i vettori grezzi
//            per poter chiamare drawCalibOverlay() in seguito.
// ════════════════════════════════════════════════════════════
static CalibResult calibrateSpectrum(TTree*             treeCh1,
                                      double             cutoff_MHz,
                                      double             fs_MHz,
                                      const std::string& tag,
                                      OutCtx&            ctx,
                                      CalibScanData*     scanOut = nullptr) {
    CalibResult res{0, 0, false};
    const int N = 1024;
    Double_t t1[N], a1[N];
    treeCh1->SetBranchAddress("time",      t1);
    treeCh1->SetBranchAddress("amplitude", a1);
    treeCh1->GetEntry(0);

    // ── Parametri scan ──────────────────────────────────────
    // SCAN_MIN = -10 mV: include la parte negativa per mostrare il
    // piedistallo/rumore a sinistra nel grafico — informazione fisica utile.
    // p.e. peak search starts from MIN_THR_MV = 6 mV (defined further
    // avanti), quindi il piedistallo non disturba la calibrazione.
    const double SCAN_MIN  = -10.0;   // mV — include il piedistallo
    const double SCAN_MAX  = 110.0;   // mV
    const double SCAN_STEP =   0.2;   // mV
    const double DER_STEP  =   1.0;   // mV — passo derivata centrata

    int n_pts = (int)std::round((SCAN_MAX - SCAN_MIN) / SCAN_STEP) + 1;
    std::vector<double> thresholds(n_pts), counts(n_pts, 0.0);
    for (int k = 0; k < n_pts; ++k)
        thresholds[k] = SCAN_MIN + k * SCAN_STEP;

    Long64_t nEntries = treeCh1->GetEntries();
    std::cout << "  Calibrating " << tag << " (" << nEntries << " events)...\n";

    // ── Event loop ──────────────────────────────────────────
    for (Long64_t i = 0; i < nEntries; ++i) {
        if (i % 500 == 0) {
            if (gROOT->IsInterrupted()) break;
            gSystem->ProcessEvents();
        }
        treeCh1->GetEntry(i);
        std::vector<double> v_t(t1, t1+N), v_a(a1, a1+N);
        std::vector<double> af = butterworthLowPass(
            correctBaseline(v_t, v_a, BASELINE_START, BASELINE_END),
            cutoff_MHz, fs_MHz);

        for (int k = 0; k < n_pts; ++k) {
            double thr = thresholds[k];
            // Isteresi 50%: arma quando segnale < thr/2, triggera quando > thr
            bool armed = false, crossed = false;
            for (int j = 0; j < N; ++j) {
                double y = af[j];
                if (!armed) { if (y < thr * 0.5) armed = true; }
                else        { if (y > thr) { crossed = true; break; } }
            }
            if (crossed) counts[k] += 1.0;
        }
    }
    // ── Derivata centrata -dN/dV ────────────────────────────
    int h = (int)std::round(DER_STEP / SCAN_STEP);
    if (h < 1) h = 1;
    int n_der = n_pts - 2*h;
    std::vector<double> thr_der(n_der), deriv(n_der), err_der(n_der);
    for (int k = h; k < n_pts - h; ++k) {
        int idx      = k - h;
        thr_der[idx] = thresholds[k];
        deriv[idx]   = -(counts[k+h] - counts[k-h]) / (2.0 * DER_STEP);
        double eU    = (counts[k+h] > 0) ? std::sqrt(counts[k+h]) : 0.0;
        double eD    = (counts[k-h] > 0) ? std::sqrt(counts[k-h]) : 0.0;
        err_der[idx] = std::sqrt(eU*eU + eD*eD) / (2.0 * DER_STEP);
    }

    // ═══════════════════════════════════════════════════════
    //  RICERCA PICCHI — approccio diretto sui massimi locali
    //
    //  Strategia:
    //  1. Smooth della derivata con box a 9 punti.
    //  2. Trova TUTTI i massimi locali con derivata positiva
    //     sopra MIN_THR_MV e con altezza >= MIN_REL * max globale.
    //  3. Separa picchi troppo vicini (min_sep adattivo).
    //  4. Identify the DOMINANT peak (tallest) = 1 p.e.
    //  5. Stima il gain come distanza tra picchi consecutivi
    //     partendo dal dominante.
    //  6. Fit lineare per ottenere gain e offset precisi.
    // ═══════════════════════════════════════════════════════
    const double MIN_THR_MV  =  6.0;  // ignora picchi sotto questa soglia [mV]
    const double MIN_REL     =  0.03; // picco deve essere >= 3% del massimo globale
    const double MIN_SEP_MV  =  3.0;  // separazione minima tra picchi [mV]

    // 1. Smooth 9-point box sulla derivata
    std::vector<double> sm(n_der, 0.0);
    for (int i = 0; i < n_der; ++i) {
        double s = 0; int c = 0;
        for (int d = -4; d <= 4; ++d) {
            int j = i + d;
            if (j >= 0 && j < n_der) { s += deriv[j]; ++c; }
        }
        sm[i] = s / c;
    }

    // 2. Massimo globale (sopra MIN_THR_MV) per normalizzare
    double globalMax = 0;
    for (int i = 0; i < n_der; ++i)
        if (thr_der[i] > MIN_THR_MV && sm[i] > globalMax)
            globalMax = sm[i];

    if (globalMax <= 0) {
        std::cerr << "[CAL] ERROR: no peaks above threshold.\n";
        return res;
    }

    // 3. Trova tutti i massimi locali significativi
    //    Un massimo locale: sm[i] > sm[i-1] && sm[i] >= sm[i+1]
    //    (usa >= a destra per gestire plateau)
    std::vector<std::pair<double,double>> rawPeaks; // {threshold_mV, height}
    for (int i = 1; i < n_der - 1; ++i) {
        if (thr_der[i] <= MIN_THR_MV) continue;
        if (sm[i] < globalMax * MIN_REL) continue;
        if (sm[i] > sm[i-1] && sm[i] >= sm[i+1])
            rawPeaks.push_back({thr_der[i], sm[i]});
    }

    if (rawPeaks.empty()) {
        std::cerr << "[CAL] ERROR: no local maxima found.\n";
        return res;
    }

    // 4. Deduplication: if two peaks are closer than MIN_SEP_MV,
    //    keep only the taller one
    std::sort(rawPeaks.begin(), rawPeaks.end()); // ordina per posizione
    std::vector<std::pair<double,double>> dedupPeaks;
    dedupPeaks.push_back(rawPeaks[0]);
    for (size_t i = 1; i < rawPeaks.size(); ++i) {
        if (rawPeaks[i].first - dedupPeaks.back().first < MIN_SEP_MV) {
            // Keep the taller one
            if (rawPeaks[i].second > dedupPeaks.back().second)
                dedupPeaks.back() = rawPeaks[i];
        } else {
            dedupPeaks.push_back(rawPeaks[i]);
        }
    }

    // Stampa tutti i massimi trovati prima dell'assegnazione
    std::cout << "  [CAL] Local maxima found (" << dedupPeaks.size() << "): ";
    for (auto& [pos, ht] : dedupPeaks)
        std::cout << std::fixed << std::setprecision(1) << pos << "mV ";
    std::cout << "\n";

    // 5. Identify the DOMINANT peak (tallest by height)
    //    This is physically the 1 p.e. or 2 p.e. -- the
    //    most abundant in a low-light run is always 1 p.e.
    int dominantIdx = 0;
    for (int i = 1; i < (int)dedupPeaks.size(); ++i)
        if (dedupPeaks[i].second > dedupPeaks[dominantIdx].second)
            dominantIdx = i;

    double dominantPos = dedupPeaks[dominantIdx].first;
    std::cout << "  [CAL] Dominant peak (1 p.e. candidate): "
              << std::fixed << std::setprecision(2) << dominantPos << " mV\n";

    // 6. Costruisce pkPos: picco dominante = 1 p.e., poi cerca
    //    i picchi successivi a distanza multipla del gain stimato.
    //    Usa solo picchi a destra del dominante (n_pe >= 1).
    //    Picchi a sinistra del dominante sono piedistallo/crosstalk.
    std::vector<double> pkPos;
    for (auto& [pos, ht] : dedupPeaks)
        if (pos >= dominantPos - 1.0)  // include dominant and everything to its right
            pkPos.push_back(pos);

    // Stima spaziatura attesa dal gap tra il dominante e il successivo
    // If only one peak, use the dominant as the only fit point
    int nFit = std::min((int)pkPos.size(), 7);
    if (nFit < 1) {
        std::cerr << "[CAL] ERROR: no peaks available for fit.\n";
        return res;
    }

    // Rimozione outlier: se un picco ha residuo > 3 mV dal fit lineare,
    // rimuovilo (ma non il primo = dominante)
    if (nFit >= 3) {
        for (int iter = 0; iter < 3 && nFit >= 3; ++iter) {
            TGraphErrors grCheck;
            for (int i = 0; i < nFit; ++i)
                grCheck.SetPoint(i, i+1, pkPos[i]);
            TF1 fCheck("fCheck_tmp2", "pol1", 0.5, nFit+0.5);
            grCheck.Fit(&fCheck, "RQ");
            double m0 = fCheck.GetParameter(1), q0 = fCheck.GetParameter(0);
            double maxRes = 0; int maxIdx = -1;
            for (int i = 1; i < nFit; ++i) {  // i=0 is the dominant, protected
                double ri = std::abs(pkPos[i] - (q0 + (i+1)*m0));
                if (ri > maxRes) { maxRes = ri; maxIdx = i; }
            }
            if (maxRes < 3.0 || maxIdx < 0) break;
            pkPos.erase(pkPos.begin() + maxIdx);
            nFit = (int)pkPos.size();
        }
    }

    std::cout << "  [CAL] Peaks used for fit (" << nFit << "): ";
    for (int i = 0; i < nFit; ++i)
        std::cout << std::fixed << std::setprecision(1) << pkPos[i] << " ";
    std::cout << "mV\n";

    // ── Fit lineare: n_pe = 1,2,... partendo dal dominante ──
    TGraphErrors* grCal = new TGraphErrors();
    for (int i = 0; i < nFit; ++i)
        grCal->SetPoint(i, i+1, pkPos[i]);
    TF1* fLin = new TF1(Form("fLin_%s", tag.c_str()), "pol1", 0.5, nFit+0.5);
    if (nFit == 1) {
        fLin->FixParameter(0, 0.0);
        fLin->SetParameter(1, pkPos[0]);
    }
    grCal->Fit(fLin, "RQ");
    res.q  = fLin->GetParameter(0);
    res.m  = fLin->GetParameter(1);
    res.ok = (res.m > 0);

    // ── Sanity check ────────────────────────────────────────
    const double GAIN_MIN = 5.0, GAIN_MAX = 50.0;
    if (res.m < GAIN_MIN || res.m > GAIN_MAX) {
        std::cerr << "[CAL] WARNING: gain = " << res.m
                  << " mV/p.e. outside [" << GAIN_MIN
                  << ", " << GAIN_MAX << "] mV/p.e.\n";
        res.ok = false;
    }
    if (std::abs(res.q) > res.m * 0.5)
        std::cerr << "[CAL] WARNING: offset = " << res.q
                  << " mV is large (>gain/2). Check calibration PNG.\n";

    std::cout << "  Calibration:  gain = " << res.m << " mV/p.e."
              << "   offset = " << res.q << " mV"
              << "   (" << nFit << " peaks)\n";

    // ── Canvas per-file: scan sopra, derivata sotto ─────────
    // Layout identico a c_vbias55_lux3.png di sipm_threshold_scan_full
    std::vector<double> xz(n_pts, 0.0), xzd(n_der, 0.0);
    TGraphErrors* grScan = new TGraphErrors(n_pts,
        thresholds.data(), counts.data(), xz.data(), xz.data());
    grScan->SetTitle(Form("Threshold scan   %s;Threshold (mV);Counts", tag.c_str()));
    grScan->SetLineColor(kAzure+1); grScan->SetLineWidth(2);

    TGraphErrors* grDer = new TGraphErrors(n_der,
        thr_der.data(), deriv.data(), xzd.data(), err_der.data());
    grDer->SetTitle(Form("-dN/dV   %s;Threshold (mV);-dN/dV  (mV^{-1})", tag.c_str()));
    grDer->SetLineColor(kRed+1); grDer->SetMarkerColor(kRed+1);
    grDer->SetMarkerStyle(20); grDer->SetMarkerSize(0.4); grDer->SetLineWidth(2);

    TCanvas* cCal = new TCanvas(Form("cCal_%s", tag.c_str()),
        Form("Calibration — %s", tag.c_str()), 950, 1000);

    TPad* pad1 = new TPad(Form("p1_%s",tag.c_str()), "scan",  0.0, 0.5, 1.0, 1.0);
    pad1->SetLeftMargin(PAD_LEFT); pad1->SetRightMargin(PAD_RIGHT);
    pad1->SetTopMargin(PAD_TOP);   pad1->SetBottomMargin(PAD_BOTTOM);
    pad1->SetGrid(); pad1->Draw();

    TPad* pad2 = new TPad(Form("p2_%s",tag.c_str()), "deriv", 0.0, 0.0, 1.0, 0.5);
    pad2->SetLeftMargin(PAD_LEFT); pad2->SetRightMargin(PAD_RIGHT);
    pad2->SetTopMargin(PAD_TOP);   pad2->SetBottomMargin(PAD_BOTTOM);
    pad2->SetGrid(); pad2->Draw();

    // Upper panel: scan curve + vertical lines at peak positions
    pad1->cd();
    grScan->Draw("AL");
    grScan->GetXaxis()->SetLimits(-15.0, 110.0);
    grScan->GetXaxis()->SetRangeUser(-15.0, 110.0);
    double yMax = *std::max_element(counts.begin(), counts.end());
    for (int i = 0; i < nFit; ++i) {
        TLine* lp = new TLine(pkPos[i], 0, pkPos[i], yMax);
        lp->SetLineColor(kOrange+7); lp->SetLineStyle(2); lp->SetLineWidth(2);
        lp->Draw("same");
    }

    // Lower panel: derivative + Gaussian fit on 1st peak + lines + legend
    pad2->cd();
    grDer->Draw("APL");
    grDer->GetXaxis()->SetLimits(-15.0, 110.0);
    grDer->GetXaxis()->SetRangeUser(-15.0, 110.0);
    // Limit Y axis to [0, 1.2*dMax] to exclude the negative pedestal spike
    // below 0 mV which otherwise dominates the scale and hides the p.e. peaks
    double dMax = *std::max_element(deriv.begin(), deriv.end());
    grDer->GetYaxis()->SetRangeUser(-dMax * 0.05, dMax * 1.25);
    for (int i = 0; i < nFit; ++i) {
        TLine* lp = new TLine(pkPos[i], 0, pkPos[i], dMax);
        lp->SetLineColor(kOrange+7); lp->SetLineStyle(2); lp->SetLineWidth(2);
        lp->Draw("same");
    }
    // Fit gaussiano sul picco dominante (diagnostica sul canvas)
    if (!pkPos.empty()) {
        double ctr = pkPos[0];
        double sg  = 1.5;  // stima conservativa: ~1 mV, capped a FIT_SIGMA_MAX
        // Stima locale sigma dall'half-max nella derivata
        for (int i = 0; i < n_der; ++i) {
            if (std::abs(thr_der[i] - ctr) < 0.3) {
                double amp0 = deriv[i];
                for (int j = i+1; j < n_der && thr_der[j] < ctr+20.0; ++j) {
                    if (deriv[j] <= amp0*0.5) {
                        sg = std::max(FIT_SIGMA_MIN,
                             std::min((thr_der[j]-ctr)/1.177, FIT_SIGMA_MAX));
                        break;
                    }
                }
                break;
            }
        }
        TF1* fG = new TF1(Form("fG1_%s",tag.c_str()), "gaus",
                           std::max(5.0, ctr-3*sg), ctr+3*sg);
        fG->SetParameters(dMax*0.5, ctr, sg);
        fG->SetParLimits(1, 5.0, MAX_THR);
        fG->SetParLimits(2, FIT_SIGMA_MIN, FIT_SIGMA_MAX);
        fG->SetLineColor(kGreen+2); fG->SetLineWidth(2);
        grDer->Fit(fG, "RQ");
        fG->Draw("same");
        double mu = fG->GetParameter(1), muE = fG->GetParError(1);
        double si = fG->GetParameter(2), siE = fG->GetParError(2);
        TPaveText* pt = new TPaveText(0.55, 0.68, 0.94, 0.88, "NDC");
        pt->SetBorderSize(1); pt->SetFillColor(0); pt->SetFillStyle(1001);
        pt->SetTextFont(42);  pt->SetTextSize(0.038);
        pt->AddText(Form("Gain   = %.3f mV/p.e.", res.m));
        pt->AddText(Form("Offset = %.3f mV",      res.q));
        pt->AddText(Form("#mu_{1} = %.3f #pm %.3f mV",  mu, muE));
        pt->AddText(Form("#sigma_{1} = %.3f #pm %.3f mV", si, siE));
        pt->Draw();
    }

    cCal->Update(); cCal->Modified();
    cCal->SaveAs(ctx.png(Form("calibration_%s.png", tag.c_str())).c_str());

    // ── Riempi CalibScanData se richiesto ───────────────────
    if (scanOut) {
        scanOut->tag        = tag;
        scanOut->thresholds = thresholds;
        scanOut->counts     = counts;
        scanOut->thr_der    = thr_der;
        scanOut->deriv      = deriv;
        scanOut->pkPos      = pkPos;
        scanOut->gain       = res.m;
        scanOut->offset     = res.q;
    }

    return res;
}

// ════════════════════════════════════════════════════════════
//  OVERLAY MULTI-FILE
//
//  Produce due canvas sovrapposte identiche a all_scans.png e
//  all_derivs.png di read_all_scans.cpp:
//    canvas sinistra  — curva N(V) in scala log Y
//    canvas destra    — derivata normalizzata al proprio massimo
//
//  Uso:
//    std::vector<CalibScanData> allData;
//    CalibScanData sd;
//    calibrateSpectrum(tree1, ..., "file1", &sd);  allData.push_back(sd);
//    calibrateSpectrum(tree2, ..., "file2", &sd);  allData.push_back(sd);
//    drawCalibOverlay(allData);
// ════════════════════════════════════════════════════════════
static void drawCalibOverlay(const std::vector<CalibScanData>& allData, OutCtx& ctx) {
    if (allData.empty()) return;
    int nf = (int)allData.size();

    // ── Canvases ─────────────────────────────────────────────
    TCanvas* cScan  = new TCanvas("cCalOverlayScan",
        "Calibration — threshold scan overlay",  1200, 700);
    TCanvas* cDeriv = new TCanvas("cCalOverlayDeriv",
        "Calibration — derivative overlay (normalised)", 1200, 700);

    for (TCanvas* cv : {cScan, cDeriv}) {
        cv->SetGrid(); cv->SetTicks(1,1);
        cv->SetLeftMargin(PAD_LEFT); cv->SetRightMargin(PAD_RIGHT);
        cv->SetTopMargin(PAD_TOP);   cv->SetBottomMargin(0.12f);
    }

    // ── Legenda ──────────────────────────────────────────────
    double legH = std::min(0.07*nf + 0.04, 0.55);
    double legX2 = 1.0 - PAD_RIGHT - 0.01;
    double legX1 = legX2 - 0.32;
    double legY2 = 1.0 - PAD_TOP  - 0.02;
    double legY1 = legY2 - legH;
    double legTxt = std::max(0.024, 0.040 - 0.002*nf);
    TLegend* legS = new TLegend(legX1, legY1, legX2, legY2);
    TLegend* legD = new TLegend(legX1, legY1, legX2, legY2);
    for (auto* leg : {legS, legD}) {
        leg->SetBorderSize(1); leg->SetFillStyle(1001);
        leg->SetFillColor(0);  leg->SetTextSize(legTxt);
    }

    bool firstS = true, firstD = true;
    std::vector<TGraph*> gScans, gDerivs;

    for (int fi = 0; fi < nf; ++fi) {
        const CalibScanData& d = allData[fi];
        int col = calibColor(fi);
        std::string label = d.tag;

        int nS = (int)d.thresholds.size();
        int nD = (int)d.thr_der.size();

        // ── Curva scan ───────────────────────────────────────
        TGraph* gS = new TGraph(nS, d.thresholds.data(), d.counts.data());
        gS->SetTitle(";Threshold (mV);Counts");
        gS->SetLineColor(col); gS->SetLineWidth(2);
        cScan->cd();
        gS->Draw(firstS ? "AL" : "L same");
        if (firstS) {
            gS->GetXaxis()->SetTitleSize(0.055); gS->GetXaxis()->SetLabelSize(0.048);
            gS->GetYaxis()->SetTitleSize(0.055); gS->GetYaxis()->SetLabelSize(0.048);
            gS->GetYaxis()->SetTitleOffset(1.05);
            cScan->SetLogy(1);
            firstS = false;
        }
        legS->AddEntry(gS, label.c_str(), "l");
        gScans.push_back(gS);

        // ── Derivata normalizzata ────────────────────────────
        // Trova il massimo nella zona fisica (> 5 mV) per normalizzare
        double peak = 0;
        for (int i = 0; i < nD; ++i)
            if (d.thr_der[i] > 5.0 && d.deriv[i] > peak) peak = d.deriv[i];

        std::vector<double> dn(nD);
        for (int i = 0; i < nD; ++i)
            dn[i] = (peak > 0) ? d.deriv[i] / peak : d.deriv[i];

        TGraph* gD = new TGraph(nD, d.thr_der.data(), dn.data());
        gD->SetTitle(";Threshold (mV);-dN/dV  (normalised to peak)");
        gD->SetLineColor(col); gD->SetLineWidth(2);
        cDeriv->cd();
        gD->Draw(firstD ? "AL" : "L same");
        if (firstD) {
            gD->GetXaxis()->SetTitleSize(0.055); gD->GetXaxis()->SetLabelSize(0.048);
            gD->GetYaxis()->SetTitleSize(0.055); gD->GetYaxis()->SetLabelSize(0.048);
            gD->GetYaxis()->SetTitleOffset(1.05);
            firstD = false;
        }
        legD->AddEntry(gD, label.c_str(), "l");
        gDerivs.push_back(gD);

        // Linee verticali sui picchi accettati (canvas derivata)
        cDeriv->cd();
        for (double pk : d.pkPos) {
            TLine* lp = new TLine(pk, -0.15, pk, 1.0);
            lp->SetLineColor(col); lp->SetLineStyle(2); lp->SetLineWidth(1);
            lp->Draw("same");
        }
    }

    // ── Range X adattivo: tronca dove tutti i file scendono sotto 0.5% ──
    double xmax = 0;
    for (auto* g : gScans) {
        double ymax = 0;
        for (int i = 0; i < g->GetN(); ++i) {
            double x, y; g->GetPoint(i, x, y);
            if (y > ymax) ymax = y;
        }
        double thr = ymax * 0.005;
        for (int i = g->GetN()-1; i >= 0; --i) {
            double x, y; g->GetPoint(i, x, y);
            if (y > thr) { if (x > xmax) xmax = x; break; }
        }
    }
    double xlo = -2.0, xhi = xmax * 1.03;
    for (auto* g : gScans)  g->GetXaxis()->SetLimits(xlo, xhi);
    for (auto* g : gDerivs) {
        g->GetXaxis()->SetLimits(xlo, xhi);
        g->GetYaxis()->SetRangeUser(-0.20, 1.20);
    }

    cScan ->cd(); legS->Draw();
    cDeriv->cd(); legD->Draw();
    cScan ->Update(); cScan ->Modified();
    cDeriv->Update(); cDeriv->Modified();

    cScan ->SaveAs(ctx.png("calib_all_scans.png").c_str());
    cDeriv->SaveAs(ctx.png("calib_all_derivs.png").c_str());
    std::cout << "  [OVERLAY] Saved: tot_calib_all_scans.png  tot_calib_all_derivs.png\n";
}
