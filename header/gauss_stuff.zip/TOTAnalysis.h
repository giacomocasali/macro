#pragma once
// header/TOTAnalysis.h
// TOT computation and event selection by number of p.e.

#include "Config.h"
#include "SignalProcessing.h"
#include "Calibration.h"
#include <vector>
#include <cmath>
#include <algorithm>

// ════════════════════════════════════════════════════════════
//  TOT EVENT STRUCTURE
// ════════════════════════════════════════════════════════════
struct TOTEvent {
    double tot;      // Time Over Threshold [ns]
    double delta_t;  // t_LET - t_laser [ns]
    double amp_max;  // peak amplitude of the waveform [mV]
    int    n_pe;     // estimated number of p.e. from calibration
};

// ════════════════════════════════════════════════════════════
//  Edge median helper
//  Returns the median of amp[i0 .. i0+n_pts-1].
//  Uses nth_element — O(n), no full sort needed.
// ════════════════════════════════════════════════════════════
static double edgeMedian(const std::vector<double>& amp,
                         int i0, int n_pts)
{
    int sz  = (int)amp.size();
    int i1  = std::max(0, i0);
    int i2  = std::min(sz, i0 + n_pts);
    if (i2 <= i1) return 0.0;
    std::vector<double> tmp(amp.begin() + i1, amp.begin() + i2);
    int mid = (int)tmp.size() / 2;
    std::nth_element(tmp.begin(), tmp.begin() + mid, tmp.end());
    return tmp[mid];
}

// ════════════════════════════════════════════════════════════
//  TOT computation with hysteresis on both edges.
//  Returns {t_rise, t_fall} at threshold.
//  Returns {-1, -1} in any rejection case.
//
//  Parameters (all have sensible defaults):
//    n_edge         = 100   samples at waveform edges for stability check
//    edge_thr_frac  = 0.5   edge median must be < frac*threshold
//    hyst_frac      = 0.5   hysteresis fraction
//    pre_check_n    = 10    samples before t_rise for pre-crossing check
//    pre_check_frac = 0.3   pre-crossing median < frac*threshold
//
//  Rejection conditions:
//  1. Edge-stability: median of first/last n_edge samples >= edge limit
//  2. Rising-edge hysteresis: discriminator arms below thr*hyst_frac,
//     fires above thr — prevents descending tails being mistaken for
//     rising edges (ringing, decay crossing threshold from above)
//  3. Pre-crossing check: median of pre_check_n samples before the
//     crossing must be < pre_check_frac*threshold — confirms signal
//     came from baseline, not from a descending tail above threshold
//  4. Falling-edge hysteresis: discriminator arms above thr*(1+hyst_frac),
//     fires below thr — prevents re-trigger on ringing just below thr
//  5. t_rise or t_fall not found within [j_start, j_end]
// ════════════════════════════════════════════════════════════
static std::pair<double,double> computeTOT(const std::vector<double>& time,
                                           const std::vector<double>& amp,
                                           double threshold,
                                           int j_start, int j_end,
                                           int    n_edge         = 100,
                                           double edge_thr_frac  = 0.5,
                                           double hyst_frac      = 0.5,
                                           int    pre_check_n    = 10,
                                           double pre_check_frac = 0.3)
{
    // ── 1. Edge-stability checks ─────────────────────────────
    const double edge_limit = edge_thr_frac * threshold;
    if (edgeMedian(amp, 0, n_edge) >= edge_limit)
        return {-1.0, -1.0};
    if (edgeMedian(amp, (int)amp.size() - n_edge, n_edge) >= edge_limit)
        return {-1.0, -1.0};

    // Hysteresis levels
    const double thr_lo = threshold * hyst_frac;          // arm level for rise
    const double thr_hi = threshold * (1.0 + hyst_frac);  // arm level for fall

    // ── 2+3. Rising-edge search with hysteresis + pre-check ─
    double t_rise = -1.0, t_fall = -1.0;
    bool armed_rise = false;

    for (int j = j_start; j <= j_end; ++j) {
        if (!armed_rise) {
            if (amp[j] < thr_lo) armed_rise = true;
        } else {
            if (amp[j] >= threshold) {
                // Interpolated crossing time
                double tr = time[j-1] + (threshold - amp[j-1])
                            * (time[j] - time[j-1]) / (amp[j] - amp[j-1]);

                // Pre-crossing check: samples immediately before must
                // be near baseline, not coming down from above threshold
                int pre_start = std::max(j_start, j - pre_check_n);
                int pre_n     = j - pre_start;
                if (pre_n > 0 &&
                    edgeMedian(amp, pre_start, pre_n) >= pre_check_frac * threshold) {
                    // Signal was not at baseline: descending tail or ringing.
                    // Reset armed state and continue searching.
                    armed_rise = false;
                    continue;
                }
                t_rise = tr;
                break;
            }
        }
    }
    if (t_rise < 0) return {-1.0, -1.0};

    // ── 4. Falling-edge search with hysteresis ───────────────
    // Must first see signal rise above thr_hi before it can fire.
    // This skips the brief re-crossings near threshold due to ringing.
    bool armed_fall = false;

    for (int j = j_start; j <= j_end; ++j) {
        if (time[j] <= t_rise) continue;
        if (!armed_fall) {
            if (amp[j] >= thr_hi) armed_fall = true;
        } else {
            if (amp[j] < threshold) {
                t_fall = time[j-1] + (threshold - amp[j-1])
                         * (time[j] - time[j-1]) / (amp[j] - amp[j-1]);
                break;
            }
        }
    }
    if (t_fall < 0) return {-1.0, -1.0};

    return {t_rise, t_fall};
}

// ════════════════════════════════════════════════════════════
//  ESTIMATE NUMBER OF p.e. FROM PEAK AMPLITUDE
//  n_pe = round((amp_max - q) / m)
//  Returns -1 if event is below threshold or not classifiable.
// ════════════════════════════════════════════════════════════
static int estimatePE(double amp_max, const CalibResult& cal,
                      double tolerance = 0.4) {
    if (!cal.ok || cal.m <= 0) return -1;
    double n_raw = (amp_max - cal.q) / cal.m;
    int    n_pe  = (int)std::round(n_raw);
    if (n_pe < 0) return 0;
    // Accept only if within tolerance*m from the nearest integer peak
    if (std::abs(n_raw - n_pe) > tolerance) return -1;
    return n_pe;
}

// ════════════════════════════════════════════════════════════
//  COLLECT TOT EVENTS from a file.
//  Fills a TOTEvent vector with all valid events.
// ════════════════════════════════════════════════════════════
static std::vector<TOTEvent> collectTOTEvents(
        TTree* treeCh1,
        TTree* treeLaser,
        double cutoff_MHz,
        double fs_MHz,
        int j_trig_start, int j_trig_end,
        double let_thr,
        const CalibResult& cal,
        const std::string& tag) {

    std::vector<TOTEvent> events;
    const int N = 1024;
    Double_t t1[N], a1[N], tL[N], aL[N];
    treeCh1->SetBranchAddress("time",      t1);
    treeCh1->SetBranchAddress("amplitude", a1);
    treeLaser->SetBranchAddress("time",      tL);
    treeLaser->SetBranchAddress("amplitude", aL);

    Long64_t nEntries = treeCh1->GetEntries();
    long nNoLaser=0, nNoTOT=0;

    std::cout << "  Processing " << nEntries << " events...\n";

    for (Long64_t i = 0; i < nEntries; ++i) {
        if (i % 500 == 0) {
            if (gROOT->IsInterrupted()) break;
            gSystem->ProcessEvents();
        }
        treeCh1->GetEntry(i);
        treeLaser->GetEntry(i);

        double t_laser = laserTriggerTime(tL, aL, N, 10.0);
        if (t_laser < -900.0) { ++nNoLaser; continue; }

        std::vector<double> v_t(t1,t1+N), v_a(a1,a1+N);
        std::vector<double> af = butterworthLowPass(
            correctBaseline(v_t, v_a, BASELINE_START, BASELINE_END),
            cutoff_MHz, fs_MHz);

        // Peak amplitude over the full waveform (for p.e. estimate)
        double amp_max = *std::max_element(af.begin(), af.end());

        // TOT at the fixed threshold
        auto [t_rise, t_fall] = computeTOT(v_t, af, let_thr,
                                            j_trig_start, j_trig_end);
        if (t_rise < 0 || t_fall < 0) { ++nNoTOT; continue; }

        double tot     = t_fall - t_rise;
        double delta_t = t_rise - t_laser;
        if (tot <= 0 || tot >= 100.0) continue;

        int n_pe = estimatePE(amp_max, cal);
        events.push_back({tot, delta_t, amp_max, n_pe});
    }

    std::cout << "  Collected: " << events.size()
              << "  |  No laser: " << nNoLaser
              << "  |  No TOT: "   << nNoTOT << "\n";
    return events;
}
