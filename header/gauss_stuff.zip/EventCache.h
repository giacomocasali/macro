#pragma once
// header/EventCache.h
// TOT event cache on ROOT file.
//
// After the waveform loop (the slow step), saves the TOTEvent vector
// to a TTree. On the next run with the same parameters
// (Vbias, LET, cutoff) reloads the TTree in <1 s instead of
// re-scanning 1M waveforms (~170 s).
//
// File name:  ../../data/events_vbias<V>_let<L>pe_cut<C>MHz.root
// Invalidation: the file is overwritten every time saveEvents() is called.
// If parameters change, the name changes -> cache miss.

#include "TOTAnalysis.h"
#include <string>
#include <vector>
#include <iostream>
#include <TFile.h>
#include <TTree.h>

static std::string eventCachePath(int vbias, double frac_pe, double cutoff_MHz,
                                   double laser_thr = 10.0,
                                   const std::string& dataDir = "../../data",
                                   bool use_filter = true) {
    // Filename encodes all parameters that affect computed values.
    // Changing any parameter -> different filename -> automatic cache miss.
    // e.g. events_vbias55_let0.50pe_cut200mhz_lthr94mV.root
    //      events_vbias55_let0.50pe_cut200mhz_lthr94mV_nofilt.root
    const char* fsuf = use_filter ? "" : "_nofilt";
    return Form("%s/events_vbias%d_let%.2fpe_cut%dmhz_lthr%dmV%s.root",
                dataDir.c_str(), vbias, frac_pe,
                (int)std::round(cutoff_MHz),
                (int)std::round(laser_thr),
                fsuf);
}

// Saves TOTEvent vector to a ROOT TTree
static void saveEvents(const std::vector<TOTEvent>& events,
                       int vbias, double frac_pe, double cutoff_MHz,
                       double laser_thr,
                       const std::string& dataDir = "../../data",
                       bool use_filter = true) {
    if (events.empty()) return;
    std::string path = eventCachePath(vbias, frac_pe, cutoff_MHz, laser_thr, dataDir, use_filter);
    TFile* f = new TFile(path.c_str(), "RECREATE");
    if (!f || f->IsZombie()) {
        std::cerr << "[EventCache] Cannot write: " << path << "\n";
        return;
    }

    Double_t tot, delta_t, amp_max;
    Int_t    n_pe;
    TTree* t = new TTree("events",
        Form("TOTEvents vbias%d let%.2fpe cut%.0fMHz lthr%.0fmV",
             vbias, frac_pe, cutoff_MHz, laser_thr));
    t->Branch("tot",     &tot,     "tot/D");
    t->Branch("delta_t", &delta_t, "delta_t/D");
    t->Branch("amp_max", &amp_max, "amp_max/D");
    t->Branch("n_pe",    &n_pe,    "n_pe/I");

    for (auto& e : events) {
        tot = e.tot; delta_t = e.delta_t;
        amp_max = e.amp_max; n_pe = e.n_pe;
        t->Fill();
    }

    f->Write(); f->Close();
    std::cout << "  [EventCache] Saved " << events.size()
              << " events -> " << path << "\n";
}

// Loads events from cache. Returns true if found, false = cache miss
static bool loadEvents(std::vector<TOTEvent>& events,
                       int vbias, double frac_pe, double cutoff_MHz,
                       double laser_thr,
                       const std::string& dataDir = "../../data",
                       bool use_filter = true) {
    std::string path = eventCachePath(vbias, frac_pe, cutoff_MHz, laser_thr, dataDir, use_filter);

    // Check file existence before opening to avoid ROOT's noisy error message
    if (gSystem->AccessPathName(path.c_str())) return false;  // file not found

    TFile* f = TFile::Open(path.c_str(), "READ");
    if (!f || f->IsZombie()) return false;

    TTree* t = (TTree*)f->Get("events");
    if (!t || t->GetEntries() == 0) { f->Close(); return false; }

    Double_t tot, delta_t, amp_max;
    Int_t    n_pe;
    t->SetBranchAddress("tot",     &tot);
    t->SetBranchAddress("delta_t", &delta_t);
    t->SetBranchAddress("amp_max", &amp_max);
    t->SetBranchAddress("n_pe",    &n_pe);

    Long64_t N = t->GetEntries();
    events.reserve((size_t)N);
    for (Long64_t i = 0; i < N; ++i) {
        t->GetEntry(i);
        events.push_back({tot, delta_t, amp_max, (int)n_pe});
    }
    f->Close();

    std::cout << "  [EventCache] Loaded " << events.size()
              << " events from " << path << "\n";
    return true;
}
