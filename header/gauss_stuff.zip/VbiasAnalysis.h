#pragma once
// header/VbiasAnalysis.h
// Multi-run analysis for a single Vbias:
//   collectTOTEvents_v4()  -- event loop over a TChain with live progress bar
//   processOneVbias()      -- finds files, loads/runs calibration, builds TChain,
//                             runs analysis with event cache support

#include "Config.h"
#include "OutputManager.h"
#include "SignalProcessing.h"
#include "Calibration.h"
#include "CalibIO.h"
#include "EventCache.h"
#include "TOTAnalysis.h"
#include "TimingCorrection.h"
#include "TOTPlotting.h"
#include "VbiasSummary.h"
#include "FilterDiagnostics.h"
#include "ProgressBar.h"
#include "SidebandAnalysis.h"

#include <iostream>
#include <iomanip>
#include <string>
#include <vector>
#include <map>
#include <cmath>
#include <chrono>
#include <algorithm>

#include <TChain.h>
#include <TFile.h>
#include <TTree.h>
#include <TH1D.h>
#include <TH2D.h>
#include <TF1.h>
#include <TSystem.h>
#include <TROOT.h>

#include "WaveformPlotter.h"
#include "PersistencePlot.h"

// ============================================================
//  collectTOTEvents_v4
//  Replaces collectTOTEvents() from TOTAnalysis.h for the v4
//  multi-run workflow.  Key differences:
//   - Live ProgressBar printed to terminal
//   - TOT upper cut raised to 150 ns (matching the wider TH2D)
//   - Both treeCh1 and treeLaser may be TChain* (they are
//     TTree* at the call site via implicit upcast)
//
//  IMPORTANT: the two chains must have been filled in the same
//  sorted order so that entry i in chainCh1 corresponds to
//  entry i in chainLaser.  processOneVbias() guarantees this.
// ============================================================
static std::vector<TOTEvent> collectTOTEvents_v4(
        TTree* treeCh1,
        TTree* treeLaser,
        double             cutoff_MHz,
        double             fs_MHz,
        int                j_trig_start,
        int                j_trig_end,
        double             let_thr,
        const CalibResult& cal,
        const std::string& tag,
        bool               use_filter   = true,
        WaveformPlotter*   wfPlotter    = nullptr,
        WaveformPlotter*   wfPlotterNeg = nullptr,
        PersistencePlotter* persPlotter  = nullptr)
{
    std::vector<TOTEvent> events;
    const int N = 1024;
    Double_t t1[N], a1[N], tL[N], aL[N];

    treeCh1  ->SetBranchAddress("time",      t1);
    treeCh1  ->SetBranchAddress("amplitude", a1);
    treeLaser->SetBranchAddress("time",      tL);
    treeLaser->SetBranchAddress("amplitude", aL);

    Long64_t nEntries = treeCh1->GetEntries();
    long nNoLaser = 0, nNoTOT = 0;

    ProgressBar bar(nEntries,
        "TOT collect  tag=" + tag +
        "  thr=" + std::to_string((int)std::round(let_thr)) + " mV" +
        (use_filter ? "" : "  [NO FILTER]"));

    for (Long64_t i = 0; i < nEntries; ++i) {
        if (bar.update(i, nNoLaser, nNoTOT, (long)events.size())) break;

        treeCh1  ->GetEntry(i);
        treeLaser->GetEntry(i);

        // Laser trigger
        double t_laser = laserTriggerTime(tL, aL, N, cal.laser_thr);
        if (t_laser < -900.0) { ++nNoLaser; continue; }

        // Baseline correction, then optionally apply Butterworth filter
        std::vector<double> v_t(t1, t1 + N), v_a(a1, a1 + N);
        std::vector<double> af = correctBaseline(v_t, v_a,
                                                 BASELINE_START, BASELINE_END);
        if (use_filter)
            af = butterworthLowPass(af, cutoff_MHz, fs_MHz);

        // Peak amplitude (for p.e. estimate)
        double amp_max = *std::max_element(af.begin(), af.end());

        // TOT via linear interpolation
        auto [t_rise, t_fall] = computeTOT(v_t, af, let_thr,
                                            j_trig_start, j_trig_end);
        if (t_rise < 0 || t_fall < 0) { ++nNoTOT; continue; }

        double tot     = t_fall - t_rise;
        double delta_t = t_rise - t_laser;

        if (tot <= 0.0 || tot >= 150.0) continue;  // unphysical TOT

        // Feed waveform to the plotters if active and still collecting
        if (wfPlotter && wfPlotter->collecting())
            wfPlotter->collect(i, v_t, af,
                               t_laser, t_rise, t_fall,
                               let_thr, estimatePE(amp_max, cal));
        if (wfPlotterNeg && wfPlotterNeg->collecting())
            wfPlotterNeg->collect(i, v_t, af,
                                  t_laser, t_rise, t_fall,
                                  let_thr, estimatePE(amp_max, cal));

        // Persistence map: collect every accepted waveform, no limit
        if (persPlotter)
            persPlotter->collect(v_t, af, t_laser, t_rise, let_thr);

        events.push_back({tot, delta_t, amp_max, estimatePE(amp_max, cal)});
    }

    bar.done();
    return events;
}

// ============================================================
//  peakFinderFromCache
//  peakFinderFromCache
//  Loads events from cache (if available) and estimates the
//  Delta_t peak position using events with small TOT.
//  Returns {peak_ns, suggested_lo, suggested_hi}.
//  Called from main BEFORE asking for the fit window,
//  so the user can make an informed choice.
//
//  If the cache does not exist yet (first run), returns {-1,-1,-1}
//  and main asks for the window as usual.
// ============================================================
static std::tuple<double,double,double> peakFinderFromCache(
        int vbias, double frac_pe, double cutoff_MHz,
        double laser_thr,
        const std::string& dataDir = DATA_DIR)
{
    std::vector<TOTEvent> events;
    if (!loadEvents(events, vbias, frac_pe, cutoff_MHz, laser_thr, dataDir))
        return {-1.0, -1.0, -1.0};
    if (events.empty())
        return {-1.0, -1.0, -1.0};

    // 15th-percentile TOT cut for event selection
    std::vector<double> tots;
    for (auto& e : events) tots.push_back(e.tot);
    std::sort(tots.begin(), tots.end());
    double tot_cut = tots[std::min((size_t)(tots.size()*0.15), tots.size()-1)];
    tot_cut = std::max(2.0, std::min(tot_cut, 15.0));

    // Fine-binned Delta_t histogram for small-TOT events
    int nB = std::max(200, (int)std::round(150.0 / 0.1));
    TH1D* hPk = new TH1D(Form("hPFCache_v%d_%.2fpe", vbias, frac_pe),
                           "", nB, -50.0, 200.0);
    hPk->SetDirectory(nullptr);
    for (auto& e : events)
        if (e.tot > 0 && e.tot < tot_cut)
            hPk->Fill(e.delta_t);

    int    bpk = hPk->GetMaximumBin();
    double tpk = hPk->GetBinCenter(bpk);
    delete hPk;

    double half = 5.0;  // suggested half-width [ns]
    return {tpk, tpk - half, tpk + half};
}


//  Full analysis pipeline for one Vbias value:
//    1. Scans ../../data/ for files matching data.vbias_<V>_run_<N>.root
//    2. Reads fs_MHz from the first file (safe: no chain boundary)
//    3. Runs threshold-scan calibration on the first run only
//       (avoids branch-address reset across TChain file boundaries)
//    4. Builds two parallel TChains (ch1 + laser) with all N runs,
//       adding files in the same sorted order -> entries 1:1 aligned
//    5. For each LET threshold: collect events, fill maps, run
//       time-walk correction and all plotting functions
//    6. Returns map  frac_pe -> {sigma, sigmaErr}  for the summary plot
// ============================================================
static std::map<double, std::pair<double,double>> processOneVbias(
        int                        vbias,
        const std::vector<double>& fracs_pe,
        double                     cutoff_MHz,
        double                     t_trig_start,
        double                     t_trig_end,
        double                     fit_lo,
        double                     fit_hi,
        TWMethod                   tw_method,
        bool                       do_pe_analysis,
        bool                       use_filter,
        OutCtx&                    ctx)
{
    std::map<double, std::pair<double,double>> sigmaOut;

    // --- 1. Find all run files -----------------------------------
    const std::string dataDir = DATA_DIR;
    const std::string pattern = "data.vbias_" + std::to_string(vbias) + "_run_";

    std::map<int, std::string> foundRuns;
    void* dirp = gSystem->OpenDirectory(dataDir.c_str());
    if (!dirp) {
        std::cerr << "[ERROR] Cannot open data directory: " << dataDir << "\n";
        return sigmaOut;
    }
    const char* entry;
    while ((entry = gSystem->GetDirEntry(dirp)) != nullptr) {
        std::string fname(entry);
        if (fname.find(pattern) == std::string::npos) continue;
        if (fname.size() < 5 || fname.substr(fname.size()-5) != ".root") continue;
        size_t pos = fname.find("_run_");
        if (pos == std::string::npos) continue;
        try {
            std::string sub = fname.substr(pos + 5);
            size_t dot = sub.find(".root");
            if (dot != std::string::npos) sub = sub.substr(0, dot);
            foundRuns[std::stoi(sub)] = dataDir + "/" + fname;
        } catch (...) {}
    }
    gSystem->FreeDirectory(dirp);

    if (foundRuns.empty()) {
        std::cerr << "[WARN] No files found for Vbias=" << vbias << "\n";
        return sigmaOut;
    }

    std::cout << "\n+==========================================================+\n"
              << "|  Vbias = " << vbias << " V  --  " << foundRuns.size()
              << " run(s) found\n"
              << "+==========================================================+\n";
    for (auto& [r, path] : foundRuns)
        std::cout << "    run " << std::setw(2) << r << " : " << path << "\n";

    // --- 2. Sampling rate from first file -----------------------
    double fs_MHz = 0.0;
    {
        TFile* f0 = TFile::Open(foundRuns.begin()->second.c_str(), "READ");
        if (!f0 || f0->IsZombie()) {
            std::cerr << "[ERROR] Cannot open first run file.\n";
            return sigmaOut;
        }
        TTree* tr = (TTree*)f0->Get("ch1");
        if (tr) {
            const int N0 = 1024; Double_t tb[N0];
            tr->SetBranchAddress("time", tb);
            tr->GetEntry(0);
            fs_MHz = 1000.0 / (tb[1] - tb[0]);
        }
        f0->Close();
    }
    if (fs_MHz <= 0.0) {
        std::cerr << "[ERROR] Cannot determine sampling rate.\n";
        return sigmaOut;
    }
    std::cout << "  Sampling rate : " << fs_MHz << " MHz\n";

    // --- 3. Calibration: try cache first, then run scan ---------
    const std::string calTag = "vbias" + std::to_string(vbias);
    CalibResult cal;

    if (loadCalibration(cal, vbias, cutoff_MHz, dataDir)) {
        // Cache hit: run FilterDiag to update cal.laser_thr
        drawFilterDiagnostics(foundRuns.begin()->second, cutoff_MHz, fs_MHz,
                              t_trig_start, t_trig_end, cal, calTag, ctx);
        // Note: laser_thr is updated in cal but NOT resaved to disk here
        // (scan data not in memory). Delete the cache and rerun calibrate
        // if you want to persist the updated laser_thr.
    } else {
        // Cache miss: run full threshold scan
        std::cout << "\n  [CALIB] No cache found. Running threshold scan on run "
                  << foundRuns.begin()->first << "...\n";
        TFile* fCal = TFile::Open(foundRuns.begin()->second.c_str(), "READ");
        if (!fCal || fCal->IsZombie()) {
            std::cerr << "[ERROR] Cannot open calibration file.\n";
            return sigmaOut;
        }
        TTree* tCal = (TTree*)fCal->Get("ch1");
        if (!tCal) {
            fCal->Close();
            std::cerr << "[ERROR] No ch1 tree in calibration file.\n";
            return sigmaOut;
        }
        CalibScanData scanData;
        cal = calibrateSpectrum(tCal, cutoff_MHz, fs_MHz, calTag, ctx, &scanData);
        fCal->Close();

        if (!cal.ok) {
            std::cerr << "[ERROR] Calibration failed for Vbias=" << vbias << "\n";
            return sigmaOut;
        }
        // FilterDiag first (updates cal.laser_thr), then save with correct thr
        drawFilterDiagnostics(foundRuns.begin()->second, cutoff_MHz, fs_MHz,
                              t_trig_start, t_trig_end, cal, calTag, ctx);
        saveCalibration(cal, scanData.thresholds, scanData.counts,
                        vbias, cutoff_MHz, dataDir);
    }

    if (!cal.ok) {
        std::cerr << "[ERROR] Calibration not valid for Vbias=" << vbias << "\n";
        return sigmaOut;
    }
    std::cout << "  Gain   = " << cal.m << " mV/p.e.\n"
              << "  Offset = " << cal.q << " mV\n";

    // --- 4. TChain over ALL runs ---------------------------------
    //  Files are added in the same sorted (run-number) order to both
    //  chains -> entry i of chainCh1 == entry i of chainLaser.
    TChain* chainCh1   = new TChain("ch1");
    TChain* chainLaser = new TChain("laser");
    for (auto& [r, path] : foundRuns) {
        chainCh1  ->Add(path.c_str());
        chainLaser->Add(path.c_str());
    }
    Long64_t totEvt = chainCh1->GetEntries();
    std::cout << "\n  Total events in TChain: " << totEvt
              << "  (" << foundRuns.size() << " runs)\n";

    if (totEvt != chainLaser->GetEntries()) {
        std::cerr << "[ERROR] ch1 and laser chain sizes differ -- "
                  << "run files may be mismatched.\n";
        delete chainCh1; delete chainLaser;
        return sigmaOut;
    }

    // --- 5. Trigger window indices (from first run) -------------
    int j_start = 0, j_end = 1023;
    {
        TFile* f0 = TFile::Open(foundRuns.begin()->second.c_str(), "READ");
        if (f0 && !f0->IsZombie()) {
            TTree* tr = (TTree*)f0->Get("ch1");
            if (tr) {
                const int N0 = 1024; Double_t tb[N0];
                tr->SetBranchAddress("time", tb); tr->GetEntry(0);
                triggerWindowIndices(tb, N0, t_trig_start, t_trig_end,
                                     j_start, j_end, calTag);
            }
            f0->Close();
        }
    }
    std::cout << "  Trigger indices: [" << j_start << ", " << j_end << "]\n";

    // --- 6. LET loop --------------------------------------------
    const double sb_width = SB::DEFAULT_SB_WIDTH;
    const double sb_ext   = SB::DEFAULT_EXT;

    std::vector<TH2D*> maps_for_overlay;

    for (double frac : fracs_pe) {
        if (gROOT->IsInterrupted()) break;

        double let_thr = cal.q + frac * cal.m;
        std::cout << "\n  +-- LET = " << frac << " p.e."
                  << "   thr = " << std::fixed << std::setprecision(2)
                  << let_thr << " mV\n";

        const std::string ltag = Form("vbias%d_let%.2fpe", vbias, frac);

        // Event collection: try cache first, else run full loop.
        // If the cache is hit we skip the loop, so waveforms cannot be
        // collected from cache — the plotter only fills during a live loop.
        std::vector<TOTEvent> events;
        bool fromCache = loadEvents(events, vbias, frac, cutoff_MHz,
                                    cal.laser_thr, dataDir, use_filter);

        // Waveform plotter: collects up to 100 waveforms with TOT < 10 ns
        // during the event loop. Disabled when loading from cache.
        WaveformPlotter wfPlotter(10.0, 100);
        // Second plotter: TOT < 10 ns AND delta_t in [-30, 0] ns
        // Used to inspect the negative-delta_t blob (dark count / prepulse)
        WaveformPlotter wfPlotterNeg(10.0, 100, -30.0, 0.0);
        // Persistence map: all accepted waveforms, aligned on t_laser
        PersistencePlotter persPlotter(let_thr);

        if (!fromCache) {
            events = collectTOTEvents_v4(
                chainCh1, chainLaser,
                cutoff_MHz, fs_MHz,
                j_start, j_end,
                let_thr, cal, ltag,
                use_filter,
                &wfPlotter, &wfPlotterNeg, &persPlotter);
            // Save to cache for next run (includes laser_thr in filename)
            if (!events.empty())
                saveEvents(events, vbias, frac, cutoff_MHz,
                           cal.laser_thr, dataDir, use_filter);
        } else {
            std::cout << "  [WFPlotter] Cache hit -- waveforms not re-collected."
                      << " Delete the cache file to regenerate waveform plots.\n";
            // Persistence map: re-scan the TChain for waveforms only.
            // We only need time/amplitude arrays + t_laser — no TOT recomputation.
            // This is fast (~same speed as the original loop) and uses no extra RAM
            // beyond the fixed TH2D (~5 MB).
            std::cout << "  [Persistence] Cache hit — re-scanning TChain for waveforms...\n";
            {
                const int N = 1024;
                Double_t t1[N], a1[N], tL[N], aL[N];
                chainCh1  ->SetBranchAddress("time",      t1);
                chainCh1  ->SetBranchAddress("amplitude", a1);
                chainLaser->SetBranchAddress("time",      tL);
                chainLaser->SetBranchAddress("amplitude", aL);

                Long64_t nEntries = chainCh1->GetEntries();
                for (Long64_t i = 0; i < nEntries; ++i) {
                    if (i % 5000 == 0) {
                        if (gROOT->IsInterrupted()) break;
                        gSystem->ProcessEvents();
                    }
                    chainCh1  ->GetEntry(i);
                    chainLaser->GetEntry(i);

                    double t_laser = laserTriggerTime(tL, aL, N, cal.laser_thr);
                    if (t_laser < -900.0) continue;

                    std::vector<double> v_t(t1, t1 + N), v_a(a1, a1 + N);
                    std::vector<double> af = correctBaseline(v_t, v_a,
                                                             BASELINE_START, BASELINE_END);
                    if (use_filter)
                        af = butterworthLowPass(af, cutoff_MHz, fs_MHz);

                    // Compute t_rise to align on it for Δt stats.
                    // Use the full waveform window — boundary check not needed here,
                    // we only need a rough t_rise for the median Δt marker.
                    auto [t_rise, t_fall] = computeTOT(v_t, af, let_thr,
                                                        j_start, j_end);
                    if (t_rise < 0) continue;  // no crossing: skip

                    persPlotter.collect(v_t, af, t_laser, t_rise, let_thr);
                }
            }
            std::cout << "  [Persistence] Re-scan done: "
                      << persPlotter.nWaveforms() << " waveforms collected.\n";
        }

        // Draw waveform plots if any were collected
        if (wfPlotter.size() > 0)
            wfPlotter.draw(ltag, ctx);
        if (wfPlotterNeg.size() > 0)
            wfPlotterNeg.draw(ltag + "_negDt", ctx);
        if (persPlotter.nWaveforms() > 0)
            persPlotter.draw(ltag, ctx);

        if (events.empty()) {
            std::cout << "  +-- No events -- skipping.\n";
            maps_for_overlay.push_back(nullptr);
            continue;
        }

        // -- Peak finder diagnostic ----------------------------
        // Plots Delta_t for events with small TOT (0 < TOT < 8 ns).
        // These are the events closest to threshold: mostly real laser
        // signal at 1 p.e., with less time walk than larger-TOT events.
        // Use this canvas to identify the correct fit window.
        {
            // Adaptive TOT cut: use the 10th percentile of TOT distribution
            // so it works for any LET, not just 1 p.e.
            std::vector<double> tots;
            for (auto& e : events) tots.push_back(e.tot);
            std::sort(tots.begin(), tots.end());
            double tot_cut = tots[std::min((size_t)(tots.size()*0.15),
                                           tots.size()-1)];
            tot_cut = std::max(2.0, std::min(tot_cut, 15.0)); // clamp [2,15] ns

            // Fine-binned Delta_t histogram for small-TOT events
            int    nB  = std::max(200, (int)std::round(150.0 / 0.1)); // 0.1 ns/bin
            TH1D*  hPk = new TH1D(Form("hPeakFinder_%s", ltag.c_str()),
                Form("Peak finder (TOT < %.1f ns)   %s"
                     ";#Deltat (ns);Events", tot_cut, ltag.c_str()),
                nB, -50.0, 200.0);
            hPk->SetDirectory(nullptr);
            int nSmall = 0;
            for (auto& e : events) {
                if (e.tot > 0 && e.tot < tot_cut) {
                    hPk->Fill(e.delta_t);
                    ++nSmall;
                }
            }

            // Find peak bin and print guidance
            int    bpk  = hPk->GetMaximumBin();
            double tpk  = hPk->GetBinCenter(bpk);
            double hpk  = hPk->GetMaximum();

            std::cout << "  [PeakFinder] TOT < " << std::fixed
                      << std::setprecision(1) << tot_cut << " ns"
                      << "  -> " << nSmall << " events\n"
                      << "  [PeakFinder] Peak at Delta_t = "
                      << std::setprecision(2) << tpk << " ns"
                      << "  (height=" << (int)hpk << ")\n"
                      << "  [PeakFinder] Suggested fit window: ["
                      << std::setprecision(1) << tpk - 5.0
                      << ", " << tpk + 5.0 << "] ns  "
                      << "(tighten after seeing the PNG)\n";

            // Draw with vertical marker at peak
            TCanvas* cPk = new TCanvas(
                Form("cPeakFinder_%s", ltag.c_str()),
                Form("Peak finder -- %s", ltag.c_str()), 900, 500);
            cPk->SetGrid();
            cPk->SetLeftMargin(PAD_LEFT); cPk->SetRightMargin(PAD_RIGHT);
            cPk->SetBottomMargin(PAD_BOTTOM); cPk->SetTopMargin(PAD_TOP);
            hPk->SetLineColor(kAzure+1); hPk->SetLineWidth(2);
            // Zoom around peak for readability
            hPk->GetXaxis()->SetRangeUser(tpk - 30.0, tpk + 30.0);
            hPk->Draw("HIST");
            TLine* lPk = new TLine(tpk, 0, tpk, hpk);
            lPk->SetLineColor(kRed+1); lPk->SetLineStyle(2);
            lPk->SetLineWidth(2); lPk->Draw("same");
            {
                TPaveText* pt = new TPaveText(0.55, 0.72, 0.93, 0.88, "NDC");
                pt->SetBorderSize(1); pt->SetFillColor(0);
                pt->SetTextFont(42);  pt->SetTextSize(0.036);
                pt->AddText(Form("TOT < %.1f ns  (%d events)", tot_cut, nSmall));
                pt->AddText(Form("Peak at #Deltat = %.2f ns", tpk));
                pt->AddText(Form("Suggested window: [%.1f, %.1f] ns",
                                  tpk-5.0, tpk+5.0));
                pt->Draw();
            }
            cPk->Update(); cPk->Modified();
            ctx.savePNG(cPk, Form("peak_finder_%s.png", ltag.c_str()));
        }
        TH2D* h2D = fillTH2D(events, ltag, frac, false);
        drawTOTMap(h2D, ltag, ctx, false);
        drawGlobalProjection(h2D, ltag, fit_lo, fit_hi, ctx, false);

        // Time-walk correction
        auto events_corr = applyTimeWalkCorrection(
            events, tw_method, fit_lo, fit_hi, ltag, ctx);

        TH2D* h2D_final = h2D;
        if (tw_method != TWMethod::NONE) {
            TH2D* h2D_corr = fillTH2D(events_corr, ltag, frac, true);
            drawTOTMap(h2D_corr, ltag, ctx, true);
            drawGlobalProjection(h2D_corr, ltag, fit_lo, fit_hi, ctx, true);
            if (do_pe_analysis)
                drawByPE(events_corr, ltag, fit_lo, fit_hi, ctx);
            ctx.saveRoot(h2D, h2D_corr, ltag, frac);
            h2D_final = h2D_corr;
        } else {
            if (do_pe_analysis)
                drawByPE(events, ltag, fit_lo, fit_hi, ctx);
            ctx.saveRoot(h2D, nullptr, ltag, frac);
        }

        // -- Sideband subtraction + S+B fit ----------------------
        // Uses time-walk corrected events when correction is applied.
        // Optional TOT upper cut removes multi-p.e. events with residual
        // time walk that bias the background estimate.
        // Re-centering uses a robust weighted-mean within the fit window
        // (not outside it) to avoid being pulled by the second TOT cluster.
        {
            const auto& evSrc = (tw_method != TWMethod::NONE)
                                 ? events_corr : events;

            // Optional TOT upper cut for the SB analysis.
            // Set > 0 to exclude multi-p.e. events (e.g. 15 ns).
            // 0 = disabled (use all events).
            const double tot_cut_sb = 0.0;  // [ns], 0 = disabled

            std::vector<TOTEvent> evSB;
            evSB.reserve(evSrc.size());
            for (auto& e : evSrc)
                if (tot_cut_sb <= 0.0 || e.tot < tot_cut_sb)
                    evSB.push_back(e);
            if (tot_cut_sb > 0.0)
                std::cout << "  [SB] TOT cut: TOT < " << tot_cut_sb
                          << " ns  -> " << evSB.size() << " / "
                          << evSrc.size() << " events kept\n";

            // Re-centre the fit window on the corrected peak.
            // Use the same weighted-mean approach as drawGlobalProjection:
            // find the bin maximum in the fit window, then refine with a
            // weighted mean in a narrow +/-4 ns window around it.
            // The second TOT blob sits mostly at the LEFT edge of the window
            // (lower Delta_t), so we search the maximum starting from the
            // centre of the window rightward to avoid being pulled left.
            double sb_fit_lo = fit_lo;
            double sb_fit_hi = fit_hi;
            {
                double win     = fit_hi - fit_lo;
                double centre  = 0.5 * (fit_lo + fit_hi);
                int    nB      = std::max(50, (int)std::round(win / 0.2));
                TH1D*  hPk     = new TH1D(Form("hSBpk_%s", ltag.c_str()),
                                          "", nB, fit_lo, fit_hi);
                hPk->SetDirectory(nullptr);
                for (auto& e : evSB)
                    if (e.delta_t >= fit_lo && e.delta_t < fit_hi)
                        hPk->Fill(e.delta_t);

                // Find max in [centre-2, fit_hi] to skip the left blob
                int bStart = hPk->FindBin(centre - 2.0);
                int bEnd   = hPk->GetNbinsX();
                int bMax   = bStart;
                for (int b = bStart; b <= bEnd; ++b)
                    if (hPk->GetBinContent(b) > hPk->GetBinContent(bMax))
                        bMax = b;
                double rough_pk = hPk->GetBinCenter(bMax);

                // Refine with weighted mean in +-4 ns
                double sw = 0, swx = 0;
                for (int b = 1; b <= hPk->GetNbinsX(); ++b) {
                    double x = hPk->GetBinCenter(b);
                    double c = hPk->GetBinContent(b);
                    if (std::abs(x - rough_pk) <= 4.0) { sw += c; swx += c*x; }
                }
                double tpk = (sw > 0) ? swx/sw : rough_pk;
                delete hPk;

                if (std::abs(tpk - centre) > 0.3) {
                    sb_fit_lo = tpk - win / 2.0;
                    sb_fit_hi = tpk + win / 2.0;
                    std::cout << "  [SB] Fit window re-centred: ["
                              << std::fixed << std::setprecision(1)
                              << sb_fit_lo << ", " << sb_fit_hi << "] ns"
                              << "  (corrected peak at "
                              << std::setprecision(2) << tpk << " ns)\n";
                }
            }

            SBResult sbr = fitSplusB(evSB, sb_fit_lo, sb_fit_hi,
                                     sb_width, sb_ext, ltag);
            drawSidebandResult(sbr, ltag, sb_fit_lo, sb_fit_hi, sb_width, ctx);

            double sigma = 0.0, sigmaErr = 0.0;
            if (sbr.fit_ok && sbr.sigma > 0.1
                           && sbr.sigma < (sb_fit_hi - sb_fit_lo)) {
                sigma    = sbr.sigma;
                sigmaErr = sbr.sigmaErr;
                sbr.sigma_source = "S+B fit";
            } else if (sbr.sub_ok && sbr.sigma_sub > 0.1
                                  && sbr.sigma_sub < (sb_fit_hi - sb_fit_lo)) {
                sigma    = sbr.sigma_sub;
                sigmaErr = sbr.sigmaErr_sub;
                sbr.sigma_source = "subtracted gaussian";
            } else {
                // Legacy Gaussian (fallback)
                int nBP = std::max(400, (int)std::round((sb_fit_hi - sb_fit_lo) / 0.02));
                TH1D* hF = new TH1D(Form("hSumFit_%s", ltag.c_str()), "",
                                     nBP, sb_fit_lo - 1.0, sb_fit_hi + 1.0);
                hF->SetDirectory(nullptr);
                for (auto& e : evSB)
                    if (e.delta_t >= sb_fit_lo && e.delta_t <= sb_fit_hi)
                        hF->Fill(e.delta_t);
                int    bpk = hF->GetMaximumBin();
                double ctr = hF->GetBinCenter(bpk);
                double sg0 = std::max(hF->GetRMS(), 0.1);
                TF1* fG = new TF1(Form("fSumG_%s", ltag.c_str()), "gaus",
                    std::max(sb_fit_lo, ctr - 2.0*sg0),
                    std::min(sb_fit_hi, ctr + 2.0*sg0));
                fG->SetParameters(hF->GetMaximum(), ctr, sg0);
                hF->Fit(fG, "RQN");
                sigma    = std::abs(fG->GetParameter(2));
                sigmaErr = fG->GetParError(2);
                sbr.sigma_source = "legacy gaussian";
                std::cout << "  [SB] WARNING: using legacy gaussian for "
                          << ltag << "\n";
                delete hF; delete fG;
            }

            std::cout << "  [SB] Sigma for summary: "
                      << std::fixed << std::setprecision(3)
                      << sigma << " +/- " << sigmaErr << " ns"
                      << "  (source: " << sbr.sigma_source << ")\n";

            if (sigma > 0.0 && sigma < (sb_fit_hi - sb_fit_lo))
                sigmaOut[frac] = {sigma, sigmaErr};

            cleanupSBResult(sbr);
        }

        maps_for_overlay.push_back(h2D_final);
        std::cout << "  +-- LET " << frac << " p.e. done.\n";
    }

    // --- 7. Multi-LET overlay -----------------------------------
    if (fracs_pe.size() > 1 && !maps_for_overlay.empty())
        drawMultiLETOverlay(fracs_pe, maps_for_overlay,
                            calTag, fit_lo, fit_hi, ctx);

    delete chainCh1;
    delete chainLaser;
    return sigmaOut;
}